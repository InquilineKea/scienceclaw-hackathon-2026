"""Batch studies for reproducible local or Nebius CPU execution."""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from simulator import PRESETS, AgingState, build_network, simulate, validate_gradient


def run_batch(out_dir="outputs", seeds=5, cols=10, rows=7, with_sweep=False):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    curve_records=[];metric_records=[]
    states=dict(PRESETS)
    if with_sweep:
        for level in np.linspace(0,1,6):
            states[f"AGE sweep {level:.1f}"]=AgingState(f"AGE sweep {level:.1f}",lox=.55,age=float(level))
            states[f"Fibrosis sweep {level:.1f}"]=AgingState(f"Fibrosis sweep {level:.1f}",lox=.55,fibrosis=float(level))
            states[f"Oxidation sweep {level:.1f}"]=AgingState(f"Oxidation sweep {level:.1f}",lox=.55,oxidation=float(level))
    for name,params in states.items():
        for seed in range(seeds):
            net,curve,met,snaps=simulate(params,seed, n_cols=cols,n_rows=rows)
            metric_records.append(dict(scenario=name,seed=seed,**met,
                                      lox=params.lox,age=params.age,oxidation=params.oxidation,
                                      fibrosis=params.fibrosis,elastin=params.elastin,age_fragility=params.age_fragility))
            for strain,force,broken,active,converged in curve:
                curve_records.append(dict(scenario=name,seed=seed,strain=strain,
                                          normalized_stress=force,broken=int(broken),
                                          remaining_links=int(active),converged=bool(converged)))
    metrics=pd.DataFrame(metric_records)
    curves=pd.DataFrame(curve_records)
    metrics.to_csv(out/'summary_by_seed.csv',index=False)
    curves.to_csv(out/'curves_by_seed.csv',index=False)
    summary=metrics.groupby('scenario').agg(n=('seed','count'),stiffness_mean=('early_stiffness','mean'),
                         stiffness_sd=('early_stiffness','std'),peak_mean=('peak_stress','mean'),
                         peak_sd=('peak_stress','std'),strain_at_peak_mean=('peak_strain','mean'),
                         work_mean=('pre_peak_work','mean'),converged_mean=('converged_fraction','mean')).reset_index()
    summary.to_csv(out/'scenario_summary.csv',index=False)

    fig,ax=plt.subplots(figsize=(10,6),layout='constrained')
    for name in PRESETS:
        data=curves[curves.scenario==name].groupby('strain').normalized_stress.agg(['mean','std']).reset_index().fillna(0)
        x=data['strain'].values*100;y=data['mean'].values;sd=data['std'].values
        ax.plot(x,y,label=name,linewidth=2)
        ax.fill_between(x,y-sd,y+sd,alpha=.12)
    ax.set(xlabel='Engineering strain (%)',ylabel='Normalized tensile traction (not Pa)',
           title=f'Aging-state network responses (mean ± SD, {seeds} random seeds)')
    ax.grid(alpha=.2);ax.legend(ncol=2,fontsize=9)
    fig.savefig(out/'stress_strain_comparison.png',dpi=170);plt.close(fig)

    fig,ax=plt.subplots(figsize=(9,6),layout='constrained')
    for name in PRESETS:
        subset=metrics[metrics.scenario==name]
        ax.scatter(subset.early_stiffness,subset.peak_stress,label=name,alpha=.75)
        ax.scatter([subset.early_stiffness.mean()],[subset.peak_stress.mean()],s=150,marker='x')
    ax.set(xlabel='Early stiffness proxy',ylabel='Peak tensile traction (not Pa)',
           title='Does stiffer mean stronger? Different aging states and random networks')
    ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.savefig(out/'stiffness_vs_strength.png',dpi=170);plt.close(fig)

    rngreport={"simulation":"Quasi-static 2D spring network, L-BFGS-B relaxation + irreversible bond failure",
        "normalized_units":True,"seeds":seeds,"n_cols":cols,"n_rows":rows,
        "strains":[round(float(x),5) for x in np.linspace(0,.30,16)],
        "finite_difference_gradient_relative_error":validate_gradient(),
        "limits":["Parameters are hypothetical, not fitted to patient or animal measurements",
                  "No molecular crosslink chemistry or real collagen constitutive calibration",
                  "Network lacks 3D alveolar geometry, viscoelasticity, hydrodynamics and airway resistance",
                  "Cannot predict FEV1, FVC, actual failure stress, lifespan, or therapeutic effects"],
        "metrics_mean":summary.round(6).to_dict('records')}
    (out/'validation.json').write_text(json.dumps(rngreport,indent=2))
    print(summary.round(3).to_string(index=False))
    print('\nGradient check:',rngreport['finite_difference_gradient_relative_error'])
    print('Saved results in',out)
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='outputs')
    ap.add_argument('--seeds',type=int,default=5)
    ap.add_argument('--cols',type=int,default=10)
    ap.add_argument('--rows',type=int,default=7)
    ap.add_argument('--sweep',action='store_true',help='Add mechanistic single-variable dose sweeps')
    args=ap.parse_args()
    if args.seeds<1:ap.error('--seeds must be >=1')
    run_batch(args.out,args.seeds,args.cols,args.rows,args.sweep)
