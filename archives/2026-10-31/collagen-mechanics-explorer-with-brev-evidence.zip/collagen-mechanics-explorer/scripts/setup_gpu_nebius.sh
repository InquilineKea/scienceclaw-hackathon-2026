#!/usr/bin/env bash
set -euo pipefail
# Run ON a provisioned Nebius GPU VM with a working CUDA driver.
# Does not authenticate to Nebius or allocate compute. Python3.12 + uv recommended.
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo 'No nvidia-smi: this stage requires an NVIDIA GPU instance' >&2
  exit 2
fi
nvidia-smi
if ! command -v uv >/dev/null 2>&1; then
  python3 -m pip install --user uv
  export PATH="$HOME/.local/bin:$PATH"
fi
uv venv --python 3.12 .venv_gpu
source .venv_gpu/bin/activate
uv pip install --extra-index-url https://download.pytorch.org/whl/cu126 --extra-index-url https://pypi.nvidia.com 'nvalchemi-toolkit[cu12]'
uv pip install ase mace-torch rdkit numpy scipy pandas matplotlib
python extensions/atomistic_pilot.py --out outputs/atomistic
# MACE-OFF23 small model is pre-trained on neutral organic molecules, not collagen crosslink chemistry.
python extensions/mace_off_runner.py --device cuda
# Validate NVIDIA ALCHEMI GPU stack using its DemoModel; NOT physical energy predictions.
python extensions/alchemi_gpu_smoke.py
