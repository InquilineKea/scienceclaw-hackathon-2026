#!/usr/bin/env bash
set -euo pipefail
# Run after SSH-ing into a provisioned Nebius VM (CPU is enough for the MVP).
# The script does not provision cloud resources or authenticate to Nebius.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements.txt
pytest -q
python batch.py --seeds 30 --out outputs/nebius_30_seeds --sweep
# Optional dashboard: streamlit run app.py --server.address 0.0.0.0
