"""Optional ScienceClaw two-agent research loop on Nebius Token Factory.

Requires: pip install openai; NEBIUS_API_KEY and NEBIUS_MODEL in environment.
This script is *not* run in the bundled results; real inference calls cost tokens.
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from simulator import AgingState, PRESETS, simulate, validate_gradient


def _ask(client, model, role, prompt):
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role":"system","content":role},
            {"role":"user","content":prompt},
        ],
        temperature=.15,
    )
    return response.choices[0].message.content or ""


def _extract_json(msg):
    # LLM responses can contain Markdown fences; accept a JSON object only.
    i=msg.find('{');j=msg.rfind('}')
    if i<0 or j<i:raise ValueError("Agent failed to return a JSON object")
    return json.loads(msg[i:j+1])


def experiment(state, seeds=5):
    records=[]
    for seed in range(seeds):
        _,_,m,_=simulate(state,seed=seed)
        records.append(m)
    return {k:{"mean":float(np.mean([r[k] for r in records])),
               "sd":float(np.std([r[k] for r in records],ddof=1)) if seeds>1 else None}
            for k in ("early_stiffness","peak_stress","peak_strain","pre_peak_work")}


def run(output="outputs/agent_run.json",seeds=5):
    if not os.environ.get("NEBIUS_API_KEY") or not os.environ.get("NEBIUS_MODEL"):
        raise RuntimeError("Set NEBIUS_API_KEY and NEBIUS_MODEL (a model ID enabled for your account)")
    from openai import OpenAI
    client=OpenAI(base_url="https://api.tokenfactory.nebius.com/v1/",api_key=os.environ["NEBIUS_API_KEY"])
    model=os.environ["NEBIUS_MODEL"]
    baseline=experiment(PRESETS["Young reference"],seeds=seeds)
    role1=("You are an ECM-aging hypothesis agent. You are not the numerical solver. "
           "Propose a single DISCRIMINATIVE model experiment. Output ONLY a JSON object "
           "with keys name (string), lox, age, oxidation, fibrosis, elastin (numbers 0 to 1), "
           "hypothesis (string) and caveat (string). Do not invent published measurements, "
           "use clinical units, or claim a molecule maps directly to a spring constant.")
    p1=_ask(client,model,role1,
            "Existing model: enzymatic LOX bridges, AGE/glucosepane-like bridges, oxidation breaks fibers, "
            "fibrosis adds paths, elastin creates weak elastic paths. Each parameter ranges 0..1. "
            f"Young reference outcome ({seeds} seeds): {json.dumps(baseline)}. "
            "Choose an informative aging scenario that helps separate stiffness from tensile capacity.")
    payload=_extract_json(p1)
    params={key:float(payload[key]) for key in ("lox","age","oxidation","fibrosis","elastin")}
    state=AgingState(name=str(payload.get('name','Agent proposal'))[:120],**params)
    observed=experiment(state,seeds=seeds)
    role2=("You are the INDEPENDENT critical methods-review agent for ScienceClaw. "
           "Do not defer to the first agent. Distinguish empirical evidence from simulated outputs. "
           "Identify confounding, hypothesis identifiability, small-N uncertainty, numerical errors, "
           "missing controls, and a concrete falsification experiment. Never invent clinical FEV1/FVC. "
           "Respond in 4 concise paragraphs.")
    p2=_ask(client,model,role2,
            "Review the following proposal and REAL simulated outcomes; check the measured data only. "
            f"First agent: {json.dumps(payload)}. Young reference: {json.dumps(baseline)}. "
            f"Proposed scenario: {json.dumps(observed)}. Gradient error: {validate_gradient():.3e}. "
            "The network is 2D normalized springs, not fitted to experimental ECM. "
            "Provide an independent critique and priority next experiment.")
    record={"generated_at_utc":datetime.now(timezone.utc).isoformat(),
            "model_used":model,"number_of_seeds":seeds,
            "hypothesis_agent":payload,"independent_review_agent":p2,
            "observed_reference":baseline,"observed_agent_condition":observed,
            "force_gradient_error":validate_gradient(),
            "validity":"Illustrative normalized simulation; no calibrated biological parameters"}
    target=Path(output);target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(record,indent=2))
    print(f"Recorded two-agent experiment to {target}")
    print(p2)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='outputs/agent_run.json')
    ap.add_argument('--seeds',type=int,default=5)
    args=ap.parse_args()
    run(args.out,args.seeds)
