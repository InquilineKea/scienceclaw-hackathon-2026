"""A reproducible coarse-grained tensile simulator for aging ECM networks.

NOT a chemically or experimentally calibrated model of collagen.
Units are deliberately normalized.  The model is a spring-network toy used to
study tradeoffs and to generate falsifiable hypotheses, not patient predictions.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
from scipy.optimize import minimize


@dataclass(frozen=True)
class AgingState:
    name: str = "Custom"
    lox: float = 0.50       # physiological LOX bridge availability (0..1)
    age: float = 0.00       # AGE/glycation bridge availability (0..1)
    oxidation: float = 0.0  # fraction of collagen links lost to oxidative cleavage (0..1)
    fibrosis: float = 0.0   # additional collagen reinforcements (0..1)
    elastin: float = 1.0    # fraction of intact elastic-matrix bonds (0..1)
    age_fragility: float = .52  # independent hypothesis: AGE suppresses fiber ductility

    def __post_init__(self):
        for key in ("lox", "age", "oxidation", "fibrosis", "elastin", "age_fragility"):
            if not 0 <= getattr(self, key) <= 1:
                raise ValueError(f"{key} must lie between 0 and 1")


PRESETS: dict[str, AgingState] = {
    "Young reference": AgingState("Young reference", lox=.55),
    "AGE-rich": AgingState("AGE-rich", lox=.55, age=.85),
    "AGE links, no fragility penalty": AgingState("AGE links, no fragility penalty", lox=.55, age=.85, age_fragility=0.),
    "Fibrotic": AgingState("Fibrotic", lox=.80, age=.10, fibrosis=.85, elastin=.80),
    "Oxidative injury": AgingState("Oxidative injury", lox=.55, oxidation=.32, elastin=.65),
    "Combined aging": AgingState("Combined aging", lox=.65, age=.65, oxidation=.20, fibrosis=.35, elastin=.65),
    "Low enzymatic crosslinks": AgingState("Low enzymatic crosslinks", lox=.07),
}


@dataclass
class Network:
    reference: np.ndarray   # (N, 2)
    ends: np.ndarray        # (E, 2)
    rest: np.ndarray        # (E,)
    spring_k: np.ndarray    # (E,)
    break_at: np.ndarray    # (E,) tensile extension fraction
    tension_only: np.ndarray  # (E,) bool
    kinds: np.ndarray      # (E,) labels
    initially_active: np.ndarray
    n_cols: int
    n_rows: int

    @property
    def left(self):
        return np.arange(0, len(self.reference), self.n_cols)

    @property
    def right(self):
        return np.arange(self.n_cols - 1, len(self.reference), self.n_cols)


def build_network(state: AgingState, seed: int = 42, n_cols: int = 10, n_rows: int = 7) -> Network:
    """Fibrillar horizontal paths, weak matrix, and two crosslink species.

    Crosslinks are effective inter-fiber bridges, not individual atomic bonds.
    All probabilities are normalized scenario values (not molar crosslink density).
    """
    if n_cols < 4 or n_rows < 3:
        raise ValueError("Network requires at least 4 columns and 3 rows")
    rng = np.random.default_rng(seed)
    base = np.array([(i/(n_cols-1),j/(n_rows-1))
                     for j in range(n_rows) for i in range(n_cols)], dtype=float)
    ref = base.copy()
    ref += rng.uniform(-.011,.011,ref.shape)
    ref[:,0] = np.where(base[:,0] == 0, 0., np.where(base[:,0] == 1., 1., ref[:,0]))
    # A single shared random geometry and edge-choice stream per seed allows paired comparisons.
    ends,ks,bs,types,only = [],[],[],[],[]
    def add(a:int,b:int,k:float,breaking:float,kind:str,tension_only:bool=True):
        ends.append((a,b)); ks.append(float(k)); bs.append(float(breaking))
        types.append(kind);only.append(tension_only)

    def ix(i,j):return j*n_cols+i
    unit = n_cols - 1
    for j in range(n_rows):
        for i in range(n_cols-1):
            # Aged oxidation induces both scission and lowered quality of surviving fibers.
            damage_draw = rng.random()
            brittle_draw = rng.random()
            if damage_draw >= state.oxidation * .75:
                b = (.17 + .15*brittle_draw) * (1-.45*state.oxidation) * (1-state.age_fragility*state.age)
                add(ix(i,j),ix(i+1,j),unit*(1-.25*state.oxidation),b,"collagen")
    for j in range(n_rows-1):
        for i in range(n_cols):
            if rng.random() < state.elastin:
                add(ix(i,j), ix(i,j+1),.10*unit,.80,"elastin", False)
            if i<n_cols-1:
                # A weak, compliant background matrix, only partly elastin-like.
                if rng.random()<state.elastin:
                    add(ix(i,j),ix(i+1,j+1),.075*unit,.75,"elastin",False)
                if rng.random()<state.elastin:
                    add(ix(i+1,j),ix(i,j+1),.075*unit,.75,"elastin",False)

            if i < n_cols-1:
                r1,r2,b1,b2=rng.random(4)
                if r1 < state.lox * .78:
                    add(ix(i,j),ix(i+1,j+1),.48*unit,.30+.10*b1,"LOX")
                if r2 < state.lox * .78:
                    add(ix(i+1,j),ix(i,j+1),.48*unit,.30+.10*b2,"LOX")
            if i < n_cols-2:
                r3,r4,b3,b4=rng.random(4)
                if r3 < state.age * .78:
                    add(ix(i,j),ix(i+2,j+1),.72*unit,.07+.05*b3,"AGE")
                if r4 < state.age * .78:
                    add(ix(i+2,j),ix(i,j+1),.72*unit,.07+.05*b4,"AGE")
    for j in range(n_rows):
        for i in range(n_cols-2):
            if rng.random() < state.fibrosis*.75:
                add(ix(i,j),ix(i+2,j),.80*unit,.15+.13*rng.random(),"scar collagen")

    pairs=np.array(ends,dtype=int)
    rest=np.linalg.norm(ref[pairs[:,1]]-ref[pairs[:,0]],axis=1)
    return Network(ref,pairs,rest,np.array(ks),np.array(bs),np.array(only,dtype=bool),
                   np.array(types),np.ones(len(pairs),dtype=bool),n_cols,n_rows)


def _energy_gradient(positions: np.ndarray, network: Network, active: np.ndarray):
    a,b=network.ends[active].T
    vec=positions[b]-positions[a]
    length=np.maximum(np.linalg.norm(vec,axis=1),1e-14)
    delta=length-network.rest[active]
    dx=np.where(network.tension_only[active],np.maximum(delta,0.0),delta)
    force=network.spring_k[active]*dx
    energy=.5*np.dot(force,dx)
    grad=np.zeros_like(positions)
    v=(force/length)[:,None]*vec
    np.add.at(grad,a,-v)
    np.add.at(grad,b,v)
    return energy,grad


def solve_equilibrium(net:Network, strain:float, active:np.ndarray,
                      initial:np.ndarray|None=None, maxiter:int=350):
    positions=net.reference.copy() if initial is None else initial.copy()
    left=net.left;right=net.right
    # Left grip fixed in x/y; right grip fixed in x, y free.
    positions[left]=net.reference[left]
    positions[right,0]=1.+float(strain)
    free=np.ones_like(positions,dtype=bool)
    free[left,:]=False
    free[right,0]=False

    def objective(values):
        positions[free]=values
        e,g=_energy_gradient(positions,net,active)
        return e,g[free]

    res=minimize(objective, positions[free].copy(), method="L-BFGS-B", jac=True,
                 options={"maxiter":maxiter,"ftol":1e-11,"gtol":1e-7})
    positions[free]=res.x
    _,grad=_energy_gradient(positions,net,active)
    # Applied force needed at the right grip = gradient of U with respect to displacement.
    reaction=float(grad[right,0].sum())
    return positions,max(0.,reaction),bool(res.success or np.max(np.abs(grad[free]))<5e-4)


def simulate(state:AgingState, seed:int=42, strains:Sequence[float]|None=None,
             n_cols:int=10,n_rows:int=7, allow_failure:bool=True):
    if strains is None:
        strains=np.linspace(0,.30,16)
    strains=np.asarray(strains,dtype=float)
    if np.any(np.diff(strains)<0) or np.min(strains)<0:
        raise ValueError("Strain sequence must be nonnegative and nondecreasing")
    net=build_network(state,seed,n_cols,n_rows)
    active=net.initially_active.copy()
    pos=net.reference.copy()
    curve=[];snapshots={}
    for eps in strains:
        # Propagate the last state affinely to provide a warm start.
        pos[:,0]=net.reference[:,0]*(1.+eps)
        for iteration in range(7):
            pos,stress,converged=solve_equilibrium(net,float(eps),active,pos)
            if not allow_failure: break
            a,b=net.ends.T
            stretch=np.linalg.norm(pos[b]-pos[a],axis=1)/net.rest-1
            newly=(stretch>net.break_at)&active
            if not np.any(newly):break
            active[newly]=False
        else:
            pos,stress,converged=solve_equilibrium(net,float(eps),active,pos)
        # If losses occurred during the last iteration the response is re-equilibrated.
        curve.append((float(eps),float(stress),int((~active).sum()),int(active.sum()),int(converged)))
        snapshots[float(eps)]=(pos.copy(),active.copy())
    arr=np.asarray(curve,dtype=float)
    # The experimental "stress" scale is a normalized boundary traction; not Pa/MPa.
    # For a robust pre-damage elastic stiffness, fit an early load range.
    linear=arr[:,0] <= .06 + 1e-10
    modulus=float(np.polyfit(arr[linear,0],arr[linear,1],1)[0]) if linear.sum()>=2 else float("nan")
    peak_idx=int(arr[:,1].argmax())
    peak=float(arr[peak_idx,1]);eps_peak=float(arr[peak_idx,0])
    # Integral of stress up to first peak; not an absolute fracture toughness.
    work=float(np.trapezoid(arr[:peak_idx+1,1],arr[:peak_idx+1,0])) if peak_idx else 0.
    metrics={"early_stiffness":modulus,"peak_stress":peak,"peak_strain":eps_peak,
             "pre_peak_work":work,"broken_links_end":int((~active).sum()),
             "total_links":len(active),"converged_fraction":float(np.mean(arr[:,4]))}
    return net,arr,metrics,snapshots


def validate_gradient(seed:int=42)->float:
    """Relative finite-difference discrepancy in the energy gradient."""
    net=build_network(PRESETS["Young reference"],seed,n_cols=6,n_rows=5)
    pos=net.reference.copy();pos[:,0]*=1.07;pos[:,1]*=1.025
    active=net.initially_active.copy()
    e,g=_energy_gradient(pos,net,active)
    i,j=12,0;h=1e-6
    pos[i,j]+=h;ep,_=_energy_gradient(pos,net,active)
    pos[i,j]-=2*h;em,_=_energy_gradient(pos,net,active)
    fd=(ep-em)/(2*h)
    return float(abs(fd-g[i,j])/(1+abs(fd)))
