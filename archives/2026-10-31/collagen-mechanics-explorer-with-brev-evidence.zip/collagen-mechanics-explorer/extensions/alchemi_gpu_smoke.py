"""Real NVIDIA ALCHEMI Toolkit GPU API smoke test using generated ECM chemistry fragments.

Run ONLY on CUDA-capable NVIDIA GPUs with nvalchemi-toolkit installed.
The included DemoModel is a software verification model, not a chemistry MLIP.
Provide --mace-checkpoint for an optional *real* GPU MLIP test. It still requires
benchmarking and does not describe collagen or chemistry-specific bond rupture.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

ELEMENTS={'H':1,'C':6,'N':7,'O':8,'S':16,'F':9,'P':15,'Cl':17,'Br':35,'I':53}


def parse_xyz(file:Path):
    rows=Path(file).read_text().splitlines()
    n=int(rows[0]); symbols=[]; coords=[]
    for row in rows[2:2+n]:
        s,x,y,z=row.split()[:4]
        symbols.append(ELEMENTS[s]);coords.append([float(x),float(y),float(z)])
    if len(coords)!=n:raise ValueError('XYZ atom count mismatch')
    return symbols,coords


def run(inputs:Path,out:Path,checkpoint:str|None=None):
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('ALCHEMI GPU test requires an actual CUDA GPU; no CPU-only result will be mislabeled GPU')
    from nvalchemi.data import AtomicData,Batch
    paths=sorted(Path(inputs).glob('*_00.xyz'))
    if not paths:raise FileNotFoundError(f'No XYZ inputs found in {inputs}')
    molecules=[]
    for f in paths:
        z,xyz=parse_xyz(f)
        molecules.append(AtomicData(positions=torch.tensor(xyz,dtype=torch.float32,device='cuda'),
                                    atomic_numbers=torch.tensor(z,dtype=torch.long,device='cuda')))
    batch=Batch.from_data_list(molecules)
    if checkpoint:
        from nvalchemi.models.mace import MACEWrapper
        model=MACEWrapper.from_checkpoint(checkpoint,device=torch.device('cuda')).eval()
        label='MACE checkpoint (domain of validity NOT assessed)'
    else:
        from nvalchemi.models.demo import DemoModel,DemoModelWrapper
        model=DemoModelWrapper(DemoModel()).to('cuda').eval()
        label='DEMO software smoke-test only, no physical meaning'
    with torch.no_grad(): outputs=model(batch)
    record={'test':'GPU batched AtomicData + model forward', 'execution':'executed',
            'device':torch.cuda.get_device_name(0),'n_fragments':len(paths),
            'model':label,'energy_shape':list(outputs['energy'].shape),
            'force_shape':list(outputs['forces'].shape),
            'not_a_collagen_simulation':True}
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(record,indent=2))
    return record


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--inputs',default='outputs/atomistic/inputs')
    p.add_argument('--out',default='outputs/alchemi_smoke.json')
    p.add_argument('--mace-checkpoint',default=None)
    a=p.parse_args()
    print(json.dumps(run(Path(a.inputs),Path(a.out),a.mace_checkpoint),indent=2))
