"""Optional real MACE-OFF23 small-molecule single-point energy evaluation.

Install ase, mace-torch, torch; checkpoints downloaded on first use. The OFF23
model is intended for neutral organics, NOT validated for collagen crosslink
chemistry, radical oxidative damage, sulfilimine formation or bond breaking.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path


def evaluate(inputs:Path,out:Path,model='small',device='cpu'):
    from ase.io import read
    from mace.calculators import mace_off
    from torch import set_num_threads
    set_num_threads(2)
    calc=mace_off(model=model,device=device)
    path=Path(inputs)
    paths=sorted(path.glob('*.xyz'))
    if not paths:raise FileNotFoundError(f'No XYZ inputs at {path}')
    records=[]
    for xyz in paths:
        atoms=read(str(xyz))
        atoms.calc=calc
        try:
            energy=float(atoms.get_potential_energy())
        except Exception as exc:
            raise RuntimeError(f'Failed evaluating {xyz.name}; may be out of model domain') from exc
        records.append(dict(xyz_filename=xyz.name,molecule=xyz.stem.rsplit('_',1)[0],
                            relative_extension_index=int(xyz.stem.rsplit('_',1)[1]),energy_eV=energy))
    baseline={}
    for r in records:
        if r['relative_extension_index']==0:baseline[r['molecule']]=r['energy_eV']
    for r in records:
        r['relative_energy_eV']=r['energy_eV']-baseline[r['molecule']]
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as handle:
        w=csv.DictWriter(handle,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    return len(records)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--inputs',default='outputs/atomistic/inputs')
    p.add_argument('--out',default='outputs/atomistic/mace_off23_energies.csv')
    p.add_argument('--model',default='small')
    p.add_argument('--device',default='cpu',choices=['cpu','cuda'])
    a=p.parse_args()
    try:n=evaluate(Path(a.inputs),Path(a.out),a.model,a.device)
    except ImportError as e:
        raise SystemExit('MACE and ASE unavailable: pip install ase mace-torch; import error: '+str(e))
    print('Evaluated',n,'structures with MACE-OFF23 model',a.model)
