"""Reproducible local capability check; never claims a cloud run without credentials."""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def checklist(out:Path):
    from simulator import PRESETS,simulate,validate_gradient
    from extensions.lammps_bridge import generate as generate_lammps
    from extensions.atomistic_pilot import run as run_atomistic
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    _,data,metric,_=simulate(PRESETS['AGE-rich'],seed=7)
    gradient=validate_gradient()
    lammps_records=generate_lammps(out/'lammps',seed=7,run=False)
    atomic_records=run_atomistic(out/'atomistic')
    has_model=bool(importlib.util.find_spec('mace')) and bool(importlib.util.find_spec('ase'))
    has_alchemi=bool(importlib.util.find_spec('nvalchemi'))
    import torch
    state={
        'scipy':{'status':'EXECUTED','model':'normalized 2D collagen ECM network',
                 'gradient_check_relative_error':gradient,'AGE_rich_peak_traction':metric['peak_stress']},
        'lammps':{'status':'PREPARED, NOT EXECUTED',
                  'available_binary':shutil.which('lmp') or shutil.which('lmp_serial'),
                  'number_of_input_decks':len(lammps_records),
                  'independent_reference':'SciPy all-harmonic bead-network equilibria'},
        'rdkit_mmff':{'status':'EXECUTED','molecular_fragment_stretch_scans':len(atomic_records),
                     'physical_scope':'generic C-C, S-S, amide C-N proxies; not collagen bonds'},
        'mace_off23':{'status':'NOT EXECUTED' if not has_model else 'DEPENDENCIES PRESENT, USER MUST RUN',
                      'ase_and_mace_available':has_model,
                      'script':'extensions/mace_off_runner.py'},
        'nvidia_alchemi':{'status':'NOT EXECUTED' if not (has_alchemi and torch.cuda.is_available()) else 'READY FOR GPU TEST',
                         'library_present':has_alchemi,'gpu_present':torch.cuda.is_available(),
                         'script':'extensions/alchemi_gpu_smoke.py'},
        'nebius_compute':{'status':'NOT EXECUTED: no VM integration in this session',
                          'script':'scripts/run_on_nebius.sh'},
        'nebius_token_factory':{'status':'NOT EXECUTED' if not (os.getenv('NEBIUS_API_KEY') and os.getenv('NEBIUS_MODEL')) else 'CREDENTIALS PRESENT, NOT CALLED',
                                'key_present':bool(os.getenv('NEBIUS_API_KEY')),
                                'model_present':bool(os.getenv('NEBIUS_MODEL')),
                                'script':'nebius_agents.py'},
        'integrity':'All stages labeled accurately; no fake cloud/MLIP runs.'}
    (out/'multiscale_status.json').write_text(json.dumps(state,indent=2))
    return state


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='outputs')
    a=p.parse_args()
    state=checklist(Path(a.out))
    for k,v in state.items():
        if isinstance(v,dict):print(k+': '+v['status'])
