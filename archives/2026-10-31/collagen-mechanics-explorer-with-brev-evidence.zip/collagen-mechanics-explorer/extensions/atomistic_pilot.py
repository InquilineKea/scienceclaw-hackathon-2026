"""Molecular-force-field screening, plus MACE-OFF23-ready fixed-geometry scans.

This is NOT a collagen-crosslink rupture simulation. RDKit MMFF is an available
small-molecule baseline. MACE requires optional mace-torch + ase packages and
checkpoint access. C-C, S-S, and amide C-N are generic local bond fragments,
not glucosepane, sulfilimine, pyridinoline, or full collagen architecture.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Geometry import Point3D

# Local, neutral stand-ins, no claim of direct clinical force parameters.
MOLECULES = {
    'carbon_carbon': dict(smiles='CC', bond=(0,1), description='ethane C-C backbone-like surrogate'),
    'disulfide':dict(smiles='CSSC', bond=(1,2), description='dimethyl disulfide S-S; chemistry relevant to collagen VII dimer links'),
    'amide_CN':dict(smiles='CC(=O)NC', bond=(1,3), description='N-methylacetamide amide C-N; generic isopeptide-like motif'),
}


def make_molecule(smiles,seed=15):
    mol=Chem.AddHs(Chem.MolFromSmiles(smiles))
    if AllChem.EmbedMolecule(mol,randomSeed=seed) != 0:
        raise RuntimeError(f'Could not embed {smiles}')
    result=AllChem.MMFFOptimizeMolecule(mol,maxIters=500)
    if result < 0: raise RuntimeError(f'MMFF parameters unavailable: {smiles}')
    return mol


def side_atoms(mol,a,b):
    """Connected side of b after omitting the target bond; reject ring bonds."""
    seen={b}; stack=[b]
    while stack:
        idx=stack.pop()
        for neighbor in mol.GetAtomWithIdx(idx).GetNeighbors():
            t=neighbor.GetIdx()
            if (idx==a and t==b) or (idx==b and t==a):continue
            if t not in seen:
                seen.add(t);stack.append(t)
    if a in seen:raise ValueError('target bond is in a ring, not suitable for fixed-side translation')
    return sorted(seen)


def stretch(mol,a,b,relative):
    copy=Chem.Mol(mol)
    conf=copy.GetConformer()
    coords=np.array(conf.GetPositions())
    vec=coords[b]-coords[a]
    length=float(np.linalg.norm(vec))
    direction=vec/length
    for atom_id in side_atoms(copy,a,b):
        new_pos=coords[atom_id]+relative*length*direction
        conf.SetAtomPosition(atom_id,Point3D(*map(float,new_pos)))
    return copy,length*(1+relative),length


def write_xyz(mol,where:Path,label:str):
    coords=mol.GetConformer().GetPositions()
    lines=[str(mol.GetNumAtoms()),label]
    for i,xyz in enumerate(coords):
        lines.append(f'{mol.GetAtomWithIdx(i).GetSymbol():2} {xyz[0]:.9f} {xyz[1]:.9f} {xyz[2]:.9f}')
    where.write_text('\n'.join(lines)+'\n')


def run(out:Path):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    inp=out/'inputs';inp.mkdir(exist_ok=True)
    records=[]
    for name,design in MOLECULES.items():
        mol=make_molecule(design['smiles'])
        a,b=design['bond']
        props=AllChem.MMFFGetMoleculeProperties(mol)
        for idx,relative in enumerate(np.linspace(0,.22,12)):
            modified,length,length0=stretch(mol,a,b,float(relative))
            ff=AllChem.MMFFGetMoleculeForceField(modified,props)
            value=float(ff.CalcEnergy())
            xyz_name=f'{name}_{idx:02d}.xyz'
            write_xyz(modified,inp/xyz_name,f'{name} fraction={relative:.5f} bond_length_angstrom={length:.6f}')
            records.append(dict(molecule=name,smiles=design['smiles'],description=design['description'],
                                relative_extension=float(relative),bond_length_A=length,
                                equilibrium_bond_length_A=length0,
                                MMFF_energy_kcal_mol=value,xyz_filename=xyz_name))
    for name in MOLECULES:
        pts=[r for r in records if r['molecule']==name]
        base=pts[0]['MMFF_energy_kcal_mol']
        for r in pts:r['MMFF_relative_energy_kcal_mol']=r['MMFF_energy_kcal_mol']-base
    with (out/'mmff_bond_scans.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    try:
        import matplotlib;matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(7.3,4.8),layout='constrained')
        for name in MOLECULES:
            pts=[r for r in records if r['molecule']==name]
            ax.plot([p['relative_extension']*100 for p in pts],
                    [p['MMFF_relative_energy_kcal_mol'] for p in pts],
                    marker='o',label=name.replace('_',' '))
        ax.set(xlabel='Imposed local bond extension (%)',ylabel='Relative MMFF energy (kcal/mol)',
               title='Small-molecule force-field scans (NOT tissue failure predictions)')
        ax.grid(alpha=.2);ax.legend();fig.savefig(out/'molecular_fragment_energy.png',dpi=170);plt.close(fig)
    except ImportError:pass
    (out/'provenance.json').write_text(json.dumps({
        'status':'RDKit MMFF local molecular calculations executed; MACE not involved',
        'n_structures':len(records),'molecule_count':len(MOLECULES),
        'comparison':'Energy changes relative to each molecule own zero-extension geometry',
        'limitations':['no crosslink formation/breaking','no collagen helix or solvent',
                       'all heavy-atom groups moved rigidly, no post-stretch relaxation',
                       'generic chemical surrogates only; no glucosepane, sulfilimine or pyridinoline',
                       'no physical coupling to coarse-grained tissue parameters']},indent=2))
    return records


if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--out',default='outputs/atomistic')
    opt=a.parse_args()
    rec=run(Path(opt.out))
    print(f'Generated {len(rec)} relaxed-start, rigidly stretched molecular configurations and MMFF energies')
