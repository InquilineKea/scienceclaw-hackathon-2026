"""Export the existing ECM network to an independent LAMMPS bonded-bead tensile solver.

One bond *type* per bond intentionally preserves heterogeneous individual rest
lengths and spring coefficients. The independent LAMMPS solver uses full harmonic
springs without bond failure; it is NOT equivalent to the parent model's
compression-clipped and irreversibly failing springs.
"""
from __future__ import annotations
import argparse
import csv
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from simulator import PRESETS, Network, build_network


def energy_gradient(pos: np.ndarray, net: Network):
    """Exact all-harmonic energy and gradients matching LAMMPS bond_style harmonic."""
    aa, bb = net.ends.T
    diff = pos[bb] - pos[aa]
    length = np.maximum(np.linalg.norm(diff,axis=1), 1e-14)
    dl = length - net.rest
    e = 0.5 * np.dot(net.spring_k, dl*dl)
    grad = np.zeros_like(pos)
    direction = ((net.spring_k*dl)/length)[:,None]*diff
    np.add.at(grad, aa, -direction)
    np.add.at(grad, bb, direction)
    return float(e), grad


def reference_harmonic(net: Network, strain: float):
    """Independent SciPy validation reference for LAMMPS all-harmonic spring law."""
    pos = net.reference.copy()
    pos[net.right, 0] = 1.0 + strain
    free = np.ones_like(pos,dtype=bool)
    free[net.left,:] = False
    free[net.right,0] = False
    def obj(xx):
        pos[free] = xx
        e,g = energy_gradient(pos,net)
        return e,g[free]
    result = minimize(obj,pos[free].copy(),method='L-BFGS-B',jac=True,
                     options={'maxiter':1500,'ftol':1e-13,'gtol':1e-8})
    pos[free] = result.x
    e,g = energy_gradient(pos,net)
    return pos, float(g[net.right,0].sum()), e, bool(result.success or np.max(abs(g[free])) < 5e-4)


def write_data(net: Network, strain: float, dest: Path):
    """LAMMPS data file; atom_style bond; one bond type per bond."""
    dest = Path(dest)
    pts=net.reference.copy()
    pts[net.right,0]=1. + strain
    n = len(pts);m=len(net.ends)
    text = [f'ECM coarse-grained network strain={strain:.4f}', '',
            f'{n} atoms', f'{m} bonds', '', '1 atom types', f'{m} bond types', '',
            '-1.0 3.0 xlo xhi','-1.0 2.0 ylo yhi','-0.5 0.5 zlo zhi','',
            'Masses','', '1 1.0','', 'Atoms # bond','']
    for i,p in enumerate(pts,1):
        text.append(f'{i} 1 1 {p[0]:.12g} {p[1]:.12g} 0.0')
    text += ['', 'Bonds', '']
    for bi,(a,b) in enumerate(net.ends,1):
        text.append(f'{bi} {bi} {a+1} {b+1}')
    dest.write_text('\n'.join(text)+'\n')
    return pts


def write_input(net: Network, dest: Path):
    """LAMMPS 2D quasistatic minimization with fixed/displaced grips."""
    left_ids=' '.join(str(x+1) for x in net.left)
    right_ids=' '.join(str(x+1) for x in net.right)
    text = ['# Uncalibrated, normalized network; not an atomistic collagen force field',
            'clear','units lj','dimension 2','boundary f f p','atom_style bond',
            'read_data network.data', 'pair_style none','bond_style harmonic',
            '# Note: LAMMPS harmonic energy is K*(r-r0)^2; SciPy is 0.5*k*(r-r0)^2',]
    for i,(k,l0) in enumerate(zip(net.spring_k,net.rest),1):
        text.append(f'bond_coeff {i} {0.5*k:.12g} {l0:.12g}')
    text += [f'group left_grip id {left_ids}',f'group right_grip id {right_ids}',
             'fix lock_left left_grip setforce 0.0 0.0 0.0',
             'fix lock_right right_grip setforce 0.0 0.0 0.0',
             'min_style cg','thermo 200','thermo_style custom step pe fnorm',
             'minimize 1.0e-11 1.0e-9 2000 10000',
             'write_dump all custom relaxed.dump id x y z modify sort id',
             'print "COLLAGEN_LAMMPS_COMPLETE"']
    Path(dest).write_text('\n'.join(text)+'\n')


def read_dump(path:Path,n:int):
    lines=Path(path).read_text().splitlines()
    prefix='ITEM: ATOMS '
    header_idx=next(i for i,t in enumerate(lines) if t.startswith(prefix))
    fields=lines[header_idx].split()[2:]
    ids,xx,yy=fields.index('id'), fields.index('x'), fields.index('y')
    pos=np.zeros((n,2))
    for line in lines[header_idx+1:header_idx+1+n]:
        parts=line.split();pos[int(parts[ids])-1]=[float(parts[xx]),float(parts[yy])]
    return pos


def generate(out:Path,seed:int=7,strains=(0,.05,.10,.15),run=False):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    exe=shutil.which('lmp') or shutil.which('lmp_serial')
    if run and not exe:
        raise RuntimeError('LAMMPS executable missing. Install LAMMPS and put lmp on PATH.')
    results=[]
    for name in ('Young reference','AGE-rich','Fibrotic'):
        net=build_network(PRESETS[name],seed=seed,n_cols=8,n_rows=5)
        for strain in strains:
            d=out/name.replace(' ','_')/f'strain_{int(round(strain*100)):02d}'
            d.mkdir(parents=True,exist_ok=True)
            write_data(net,strain,d/'network.data')
            write_input(net,d/'in.collagen')
            predicted, f,e,ok=reference_harmonic(net,strain)
            row={'scenario':name,'strain':float(strain),'scipy_harmonic_traction':f,
                 'scipy_energy':e,'scipy_converged':ok,'lammps_ran':False,
                 'lammps_traction':'','lammps_vs_scipy_force_abs_error':'',
                 'lammps_vs_scipy_RMS_position_error':''}
            if run:
                log=(d/'lammps.stdout.log').open('w')
                try:
                    subprocess.run([exe,'-in','in.collagen','-log','run.log'],cwd=d,
                                   check=True,stdout=log,stderr=subprocess.STDOUT,timeout=120)
                finally:
                    log.close()
                lammps_pos=read_dump(d/'relaxed.dump',len(net.reference))
                _,g=energy_gradient(lammps_pos,net)
                lmp_force=float(g[net.right,0].sum())
                row.update(lammps_ran=True,lammps_traction=lmp_force,
                           lammps_vs_scipy_force_abs_error=abs(lmp_force-f),
                           lammps_vs_scipy_RMS_position_error=float(np.sqrt(np.mean((lammps_pos-predicted)**2))))
            results.append(row)
    keys=list(results[0].keys())
    with (out/'solver_comparison.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(results)
    (out/'status.json').write_text(json.dumps({
        'lammpsexecutable':exe,'actual_lammps_execution':run,
        'files_generated':len(results),'seed':seed,'comparison':'all-harmonic springs, no rupture',
        'why_not_directly_comparable_to_main':'main SciPy simulator includes compression-clipped fibers and bond failure',
        'units':'normalized LJ-style model units, no real nm/kPa calibration'
    },indent=2))
    return results


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='outputs/lammps')
    p.add_argument('--seed',type=int,default=7)
    p.add_argument('--run',action='store_true',help='Actually run LAMMPS executable; otherwise generate input decks and SciPy references')
    a=p.parse_args()
    records=generate(Path(a.out),seed=a.seed,run=a.run)
    print('Generated',len(records),'LAMMPS experiments; executed:',a.run)
