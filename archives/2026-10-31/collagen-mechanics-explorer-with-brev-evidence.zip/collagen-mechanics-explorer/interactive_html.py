"""Build an offline interactive Plotly figure from already-computed physical simulations."""
import pandas as pd
import plotly.graph_objects as go
from pathlib import Path

root=Path(__file__).resolve().parent
curves=pd.read_csv(root/'outputs/curves_by_seed.csv')
name_order=['Young reference','AGE-rich','AGE links, no fragility penalty','Fibrotic','Oxidative injury','Combined aging','Low enzymatic crosslinks']
fig=go.Figure()
for name in name_order:
    sub=curves[curves.scenario==name].groupby('strain').normalized_stress.agg(['mean','std']).fillna(0).reset_index()
    fig.add_trace(go.Scatter(x=100*sub.strain,y=sub['mean'],mode='lines+markers',name=name,
                             visible=True if name in ('Young reference','AGE-rich') else 'legendonly'))
buttons=[]
for name in name_order:
    visible=['legendonly']*len(name_order)
    visible[0]=True
    visible[name_order.index(name)]=True
    buttons.append(dict(label=name,method='update',args=[{'visible':visible},
                {'title':f'Collagen Mechanics Explorer · Young vs {name}'}]))
fig.update_layout(title='Collagen Mechanics Explorer · Young vs AGE-rich',
    xaxis_title='Engineering tensile strain (%)',yaxis_title='Normalized tensile traction (not Pa)',
    template='plotly_white',height=580,
    margin=dict(l=65,r=40,t=105,b=65),
    updatemenus=[dict(type='dropdown',active=1,buttons=buttons,x=.01,y=1.18,xanchor='left')],
    annotations=[dict(text='SIMULATED: 2D spring network, 5 seeds per condition. Not calibrated to clinical tissue mechanics.',
                      xref='paper',yref='paper',x=.0,y=-.24,showarrow=False,font=dict(size=11))])
fig.write_html(root/'outputs/explorer.html',include_plotlyjs=True,full_html=True)
print('Saved offline interactive chart:',root/'outputs/explorer.html')
