# Collagen Mechanics Explorer 🧬
**ScienceClaw 2026 — scaffold for a 24-hour aging/ECM science experiment.**

## The question
Does age-related matrix stiffening necessarily improve tissue support or mechanical resilience? Compare physiological enzymatic LOX-type inter-fiber bridges, AGE/glucosepane-like nonenzymatic bridges, oxidative cleavage, fibrotic collagen reinforcement, and loss of weak elastic connections. The code is a **hypothesis-generating 2D spring network**, not a validated collagen molecular/tissue model.

## Install / run (local Mac, Linux, Nebius VM)
```bash
cd collagen-mechanics-explorer
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
streamlit run app.py
```

## Run actual stress-strain experiments
```bash
python batch.py --seeds 5 --out outputs
python batch.py --seeds 30 --sweep --out outputs/nebius_30_seeds
```

`batch.py` exports each seed's normalized tensile stress/strain trace, replicate metrics, plots and a provenance/limitations report. Files:
- `outputs/stress_strain_comparison.png`: mean and SD curves for six damage scenarios
- `outputs/stiffness_vs_strength.png`: stiffness versus peak traction
- `outputs/curves_by_seed.csv`: unaggregated simulation points
- `outputs/summary_by_seed.csv`: per-seed response metrics
- `outputs/scenario_summary.csv`: means and SD
- `outputs/validation.json`: numerical checks and model limitations

To use **Nebius**: provision a CPU VM via the Nebius Compute console, SSH in, copy the folder, then run `bash scripts/run_on_nebius.sh`. If credits are restricted to hosted scientific-model API endpoints, a generic Python simulator may require separate Nebius Compute access. Neither VM provisioning nor Cloud API requests are automated by this repository. GPU use is **not necessary** for this small model.

## Toy mechanics (actual numerical solve)
A rectangular network of stagger/jittered nodes has horizontal collagen fiber springs and a compliant elastic-matrix background. LOX bridges connect nearby fibers; AGE bridges reach nearby fibers but have distinct stiffness and lower rupture thresholds; an independently adjustable parameter models reduced ductility of existing fibers; oxidation removes some collagen links and reduces surviving-fiber quality; fibrosis inserts additional collagen load paths. Each tensile step fixes the left grip and displaces the right grip; the free nodes minimize

`U = sum(0.5 * k_e * extension_e**2)`

using analytic derivatives and L-BFGS-B. A fiber is tension-only; elastin-like links can bear compression. Links exceeding their assigned critical stretch irreversibly fail and the graph is re-equilibrated. The net right-grip reaction force is a **normalized tensile traction**. Individual stiffness/rupture/availability values are chosen for a sensitivity experiment, **not fitted to collagen chemistry**. A reported "0.8 AGE" means 80% of the modeled candidate-bridge probability parameter, **not** a physical mole fraction of crosslinked lysines. This is NOT a crosslink-density-to-megapascals calibration. The Streamlit UI offers an **optional explicit reference-modulus input**, which rescales the simulated traction into kPa by matching the young-reference small-strain slope to the user-supplied experimental modulus. This produces dimensionally scaled results, not an independently validated tissue prediction; leave it at zero without suitable empirical measurements.

Metrics:
- Early tensile stiffness: slope of stress-strain curve through 6% strain, in normalized units
- Peak traction: largest computed load during displacement-controlled loading
- Strain at peak and work up to global maximum stress (a proxy; **not fracture toughness**)
- Broken-link count; numeric gradient and convergence tests

## Biological interpretation and intellectual honesty
This minimal network can demonstrate that **stiffness, peak load and work to failure need not move together**, depending on assumptions and network topology. It **cannot prove a causal effect of glucosepane, crosslink-breaking treatments, fibrosis therapies, aging rate, or clinical lung-function decline**. Note that some real AGE experiments find increased molecular rigidity and suppressed fibrillogenesis; a simple linear spring can't capture both without new rules. The physical parameters are not identifiable from stress curves without further data.

The lung ECM includes collagen I/III for tensile support, collagen IV in alveolar basement membranes, and elastin for recoil. Type VII collagen primarily forms anchoring fibrils at the epidermal-dermal junction; it belongs in a future skin-adhesion module, not as the main lung scaffold. The relevant lung outcomes for fibrotic restriction are **FVC/TLC and pressure-volume compliance**. FEV1/FVC is often preserved or higher; actual FEV1 requires airway-resistance and airflow modeling. The present app deliberately does not report clinical FEV1 or FVC.

## Validation strategy
1. `pytest -q` checks analytical force gradients against finite differences, reproducible runs, paired geometry, stress nonnegativity, convergence, parameter validation.
2. Repeat across 30+ independent random seeds and report variability; compare with a matched reference using the same seed.
3. Implement an independent finite-element or rheology benchmark before claiming biological predictions.
4. Find experimental measurements (unmodified versus glycated tendon stress-strain; healthy versus fibrotic pulmonary ECM tensile tests) and calibrate **only to a held-out tissue-specific dataset**.
5. Run parameter ablation: AGE bridge density vs AGE-induced fiber fragility (use the built-in 'AGE links, no fragility penalty' control); oxidation scission vs oxidation weakening; fibrosis deposition vs LOX overcrosslinking.

## ScienceClaw agent extension
The reproducible physics engine is a **tool** that research agents can call. Connect a proposal agent to choose discriminative parameter sweeps and a second reviewer agent to challenge identifiability, crosslink chemistry and convergence, via the optional `nebius_agents.py` script. Compare this against a static grid of experiments for a genuine multi-agent ablation. Nebius Token Factory hosts LLMs through its OpenAI-compatible API, but it is separate from Nebius Compute (which executes these simulations). The LLM must not invent measured parameters or directly replace force calculations.

## Scientifically relevant references
- Collagen glycation, assembly, molecular rigidity: https://pubmed.ncbi.nlm.nih.gov/39805674/
- AGE molecular-to-tissue mechanical effects: https://pubmed.ncbi.nlm.nih.gov/27616134/
- AGE crosslink simulation mechanics: https://pmc.ncbi.nlm.nih.gov/articles/PMC10441443/
- Pulmonary fibrosis, collagen LOXL2/3 and tissue stiffness: https://pubmed.ncbi.nlm.nih.gov/29966587/
- Pulmonary ECM composition: https://ajp.amjpathol.org/article/S0002-9440%2816%2930017-7/fulltext
- Formal restrictive ventilatory pattern: https://publications.ersnet.org/content/erj/60/1/2101499
- Nebius Compute: https://nebius.com/compute
- Nebius Token Factory API: https://api.tokenfactory.nebius.com/docs
- ScienceClaw hackathon: https://scienceclawhack.ai/

### Optional: two real, independent Nebius LLM agents
```bash
pip install openai
export NEBIUS_API_KEY="..."     # never commit this secret
export NEBIUS_MODEL="org/model-id"  # select a working chat model from your Nebius catalog
python nebius_agents.py --seeds 5 --out outputs/agent_run.json
```
The first agent selects a new mechanistic experiment and a **separate skeptical agent** reviews the actual simulated result, with all inputs/outputs saved. This is the optional agent prototype; it has **not been run or verified against the service** because no Nebius key is attached here. It is not yet a fully decentralized collective. For ScienceClaw, add cross-team messaging and an ablation comparing reviewers versus no reviewer.

### Offline HTML visualization
`python interactive_html.py` creates `outputs/explorer.html`, a stand-alone interactive Plotly figure using computed outputs (no server needed). The full custom-parameter sliders are in the Streamlit dashboard.

---

## Multiscale extension: SciPy → LAMMPS → MACE → NVIDIA ALCHEMI → Nebius

**Status is explicit:** The SciPy tissue solver and a separate RDKit MMFF small-molecule molecular experiment execute locally. LAMMPS input decks are generated and checked against an independent *all-harmonic* SciPy reference, but are not LAMMPS execution results until you install and invoke the binary. MACE-OFF23 and NVIDIA ALCHEMI require dependencies, model weights and, for ALCHEMI, a CUDA-capable GPU. Cloud VM and Token Factory services require distinct Nebius access and are not assumed or secretly invoked.

### Run everything currently available

```bash
pytest -q
python extensions/multiscale_check.py --out outputs
# This prints exact stage statuses and writes outputs/multiscale_status.json
```

### LAMMPS (mesoscale, normalized spring networks)

```bash
python extensions/lammps_bridge.py --out outputs/lammps
# After you install an actual LAMMPS executable (lmp or lmp_serial):
python extensions/lammps_bridge.py --out outputs/lammps --run
```

This generates **12 separate loading cases** (young, AGE-rich, fibrotic × four strains). The LAMMPS data files each have a unique type for every bond so that their individual relaxed lengths and stiffness values are retained exactly; grip nodes stay fixed during energy minimization. The exporter explicitly converts SciPy's `0.5*k*(r-r0)^2` into LAMMPS harmonic's `K*(r-r0)^2`. A per-case CSV compares the independent LAMMPS equilibrium configurations and boundary reactions against SciPy when a LAMMPS executable is available. **This independent LAMMPS verification deliberately uses all-harmonic springs WITHOUT bond breaking, unlike the main SciPy fracture model.** It is not full fibril or tissue MD.

### Small-molecule MMFF → optional MACE-OFF23 (atomistic)

```bash
python extensions/atomistic_pilot.py --out outputs/atomistic
# After installing ase mace-torch and obtaining checkpoint access:
python extensions/mace_off_runner.py --inputs outputs/atomistic/inputs --device cpu
```

The local RDKit MMFF experiment prepares 36 genuine molecular geometries: twelve imposed bond extensions each of ethane C-C, dimethyl disulfide S-S, and N-methylacetamide C-N. RDKit calculates fixed-geometry MMFF energies and writes energy traces. These are **small neutral organic bond motifs**, not molecular models of glucosepane, sulfilimine, pyridinoline, hydroxyproline-rich triple helices, or complete collagen crosslinks. The scans *do not simulate bond rupture*, and their energy rises cannot directly be inserted into tissue failure stress. MACE-OFF23 (Academic Software License) is a pretrained organic force-field option to rerun the same geometries; it must be validated for each chemical motif and may be unreliable for highly strained, bond-breaking configurations. The MACE script yields a separate output CSV only when it actually executes.

### NVIDIA ALCHEMI (GPU batching of molecular models)

```bash
# On an actual Nebius CUDA GPU instance, with separate Compute entitlement:
bash scripts/setup_gpu_nebius.sh
```

The GPU setup installs ALCHEMI Toolkit, MACE and ASE in a Python 3.12 environment, runs the atomistic fragment scans, runs real MACE-OFF23 GPU single-point calculations, and finally runs a batched `AtomicData`/`Batch`/`DemoModel` ALCHEMI **software smoke test** on the same molecular structures. The DemoModel output is intentionally NOT interpreted as chemistry. `extensions/alchemi_gpu_smoke.py` can optionally accept `--mace-checkpoint <your trained checkpoint>` for an actual ALCHEMI-wrapped MACE inference test, but this requires an appropriate, compatible checkpoint and independent verification.

### Nebius cloud compute and agent workflow

```bash
# On an existing Nebius CPU VM provisioned through its console:
bash scripts/run_on_nebius.sh

# For Nebius Token Factory: configure these securely on your own machine/VM.
export NEBIUS_API_KEY='...'
export NEBIUS_MODEL='a-current-model-id-from-your-account'
python nebius_agents.py --seeds 5 --out outputs/agent_run.json
```

The Token Factory agents select discriminating network experiments and independently critique actual simulated results. Without a key, those live model invocations do not occur. The script uses `https://api.tokenfactory.nebius.com/v1/` with the OpenAI-compatible Chat Completions API. Compute VM credentials and Token Factory API keys are **different** access mechanisms, and the VM is not automatically provisioned by these scripts. Never paste secrets into chat or commit them to the repository.

### Scope, controls and scientific honesty

This is a **cross-scale experimental scaffold**, *not yet an atomic-to-tissue calibrated model*. Results from the coarse-grained, MMFF and optional MACE stages use different units and cannot be compared numerically without an explicitly fitted and externally validated coarse-graining map. Prolyl hydroxylation stabilizes collagen triple helices; lysyl hydroxylation changes potential crosslink chemistry. LOX-derived pyridinolines, AGE glucosepane-like adducts, type-IV sulfilimine junctions, and type-VII disulfide anchoring linkages require distinct molecular models and validated parameters. An unrelated C-C or S-S surrogate is not a calculated bond energy for those collagen-specific crosslinks. No FEV1, FVC or treatment claims follow from any of these scripts without organ-scale geometry/airway mechanics and measured calibration.

Primary docs: [LAMMPS harmonic bonds](https://docs.lammps.org/bond_harmonic.html); [MACE](https://github.com/ACEsuit/mace); [ALCHEMI Toolkit](https://github.com/NVIDIA/nvalchemi-toolkit); [Token Factory API](https://api.tokenfactory.nebius.com/docs).
