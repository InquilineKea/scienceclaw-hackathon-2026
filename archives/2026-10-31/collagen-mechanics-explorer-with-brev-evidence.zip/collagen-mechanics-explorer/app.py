"""Run with: streamlit run app.py (after pip install -r requirements.txt)."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from simulator import AgingState, PRESETS, simulate, validate_gradient

st.set_page_config(page_title="Collagen Mechanics Explorer",page_icon="🧬",layout="wide")
st.title("🧬 Collagen Mechanics Explorer")
st.caption("ScienceClaw · Investigating extracellular-matrix aging, support, and failure")
st.warning("Exploratory 2D spring-network mechanics. Parameters are normalized hypotheses, not measured collagen crosslink densities, clinical predictions, or experimentally calibrated material constants.",icon="🧪")

@st.cache_data(show_spinner=False)
def run(state:AgingState,seed:int,cols:int,rows:int):
    return simulate(state,seed=seed,n_cols=cols,n_rows=rows)

with st.sidebar:
    st.subheader("Aging chemistry and ECM")
    preset=st.selectbox("Scenario",["Custom"]+list(PRESETS),index=1)
    active=PRESETS.get(preset,AgingState())
    lox=st.slider("LOX-derived enzymatic crosslinks",0.,1.,float(active.lox),.05,
                  help="Probability of stable, physiological inter-fiber bridging; not actual chemical concentration.")
    age=st.slider("AGE / glucosepane-like links",0.,1.,float(active.age),.05,
                  help="Additional nonenzymatic links + a distinct assumed fiber fragility effect.")
    fragility=st.slider("Assumed AGE-induced fiber fragility",0.,.90,float(active.age_fragility),.05,
                        help="Critical ablation: zero isolates adding AGE bridges from an assumed loss of fiber ductility.")
    oxidation=st.slider("Oxidative fiber damage",0.,1.,float(active.oxidation),.05,
                         help="Scission probability and weaker surviving fibrils.")
    fibrosis=st.slider("Fibrotic collagen reinforcement",0.,1.,float(active.fibrosis),.05,
                       help="Extra load-bearing fiber paths rather than an AGE chemistry change.")
    elastin=st.slider("Intact elastic network",0.,1.,float(active.elastin),.05,
                      help="Weak elastic supporting network, not a lung-expiratory model.")
    st.divider()
    seed=st.number_input("Geometry seed",min_value=0,max_value=99999,value=42)
    cols=st.slider("Network width (nodes)",6,14,10)
    rows=st.slider("Network height (nodes)",4,10,7)
    reference_E=st.number_input("Optional measured reference modulus (kPa)",min_value=0.0,max_value=10000000.0,value=0.0,step=1.0,
                           help="Enter a tissue-specific experimentally measured modulus to scale stress in kPa. Zero keeps honest normalized units.")
    st.caption("For quick comparison use identical geometry seeds across conditions.")

scenario=AgingState(preset,lox,age,oxidation,fibrosis,elastin,fragility)
with st.spinner("Finding mechanical equilibrium at every strain step..."):
    net,arr,stats,snaps=run(scenario,int(seed),int(cols),int(rows))
    refnet,refarr,refstats,_=run(PRESETS["Young reference"],int(seed),int(cols),int(rows))

scale = reference_E/max(refstats['early_stiffness'],1e-9) if reference_E>0 else 1.0
unit = " kPa (assumed calibration)" if reference_E>0 else " normalized"
if reference_E>0:
    st.info("Calibrated against your supplied reference modulus. This rescales the graph only; it does not validate the collagen chemistry or the model's damage predictions.",icon="📐")
c1,c2,c3,c4=st.columns(4)
c1.metric("Early tensile stiffness",f"{stats['early_stiffness']:.2f}",delta=f"{stats['early_stiffness']/max(refstats['early_stiffness'],1e-9):.2f}× vs reference")
c2.metric("Peak tensile traction",f"{stats['peak_stress']*scale:.2f}"+unit)
c3.metric("Strain at peak",f"{stats['peak_strain']*100:.0f}%")
c4.metric("Work to maximum load",f"{stats['pre_peak_work']:.3f}")

left,right=st.columns([1.05,1],gap="large")
with left:
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=100*refarr[:,0],y=refarr[:,1]*scale,mode="lines+markers",name="Young reference",line=dict(color="#728da0",width=2,dash="dot")))
    fig.add_trace(go.Scatter(x=100*arr[:,0],y=arr[:,1]*scale,mode="lines+markers",name="Selected scenario",line=dict(color="#16a2b3",width=3)))
    fig.update_layout(title="Tensile loading and progressive damage",xaxis_title="Engineering strain (%)",
                      yaxis_title="Tensile stress, kPa (assumed scale)" if reference_E>0 else "Normalized applied traction",legend=dict(orientation="h",y=-.28),height=410,margin=dict(l=15,r=15,t=55,b=5))
    st.plotly_chart(fig,use_container_width=True)
    st.caption("Stress follows from minimized spring energy and boundary reaction force. Values are normalized unless you explicitly supply a measured reference modulus.")
with right:
    step=st.slider("Visualized strain (%)",0,30,12,2)
    idx=int(round(step/2))
    idx=min(idx,len(arr)-1)
    pos,active_edges=snaps[float(arr[idx,0])]
    colors={"collagen":"#4faac0","elastin":"#a1aec1","LOX":"#28b285","AGE":"#cd83e5","scar collagen":"#e3a34b"}
    plot=go.Figure()
    for kind,color in colors.items():
        xx=[];yy=[]
        for edge_i,(a,b) in enumerate(net.ends):
            if active_edges[edge_i] and net.kinds[edge_i]==kind:
                xx.extend((pos[a,0],pos[b,0],None));yy.extend((pos[a,1],pos[b,1],None))
        plot.add_trace(go.Scatter(x=xx,y=yy,mode="lines",line=dict(color=color,width=1.7),name=kind,hoverinfo="skip"))
    xx=[];yy=[]
    for edge_i,(a,b) in enumerate(net.ends):
        if not active_edges[edge_i]:
            xx.extend((pos[a,0],pos[b,0],None));yy.extend((pos[a,1],pos[b,1],None))
    plot.add_trace(go.Scatter(x=xx,y=yy,mode="lines",line=dict(color="#d84e54",width=1,dash="dash"),name="broken",hoverinfo="skip"))
    plot.add_trace(go.Scatter(x=pos[:,0],y=pos[:,1],mode="markers",marker=dict(size=3,color="#344657"),showlegend=False,hoverinfo="skip"))
    plot.update_layout(title="Deformed network (color = bond class)",height=410,
                       xaxis=dict(range=[-.05,1.36],scaleanchor="y",scaleratio=1,visible=False),
                       yaxis=dict(range=[-.15,1.18],visible=False),
                       legend=dict(orientation="h",y=-.20,font=dict(size=10)),margin=dict(l=8,r=8,t=55,b=5))
    st.plotly_chart(plot,use_container_width=True)
    st.caption("Links that broke under the model rule are dashed red. This is not molecular geometry.")

st.subheader("How the tissue response differs by mechanism")
st.dataframe(pd.DataFrame([{"Measured surrogate":"Tensile stiffness", "Physical meaning":"Force increase per unit extension", "Aging tradeoff":"More stiffness may reduce flexibility"},
                            {"Measured surrogate":"Peak load", "Physical meaning":"Maximum applied load in the loading protocol", "Aging tradeoff":"Higher stiffness does not guarantee high strength"},
                            {"Measured surrogate":"Energy to peak load", "Physical meaning":"Area under curve up to global stress peak", "Aging tradeoff":"Not the same as clinical toughness or resilience"},
                            {"Measured surrogate":"Bond scission", "Physical meaning":"Irreversible removal above critical stretch", "Aging tradeoff":"May redistribute force or create failures"}]),hide_index=True,use_container_width=True)

with st.expander("What about lungs, FEV₁, FVC and resilience?",expanded=False):
    st.markdown("""This model tests **a flat ECM tensile strip**, not pulmonary function. Real FEV₁ depends on airway resistance, flow limitation, lung volume, breathing effort, and regional mechanics. A fibrotic lung can become stiffer and show a reduced FVC while FEV₁/FVC stays normal or rises. **None of these model outputs are spirometry values.**

Next extension: a three-dimensional collagen I/III + elastin alveolar scaffold, connected to a pressure-volume model and an independently fitted airway-flow model. Collagen IV belongs in the basement membrane; collagen VII is better reserved for skin anchoring mechanics.
""")

download_data={"strain":arr[:,0],"traction_normalized":arr[:,1],"cumulative_broken":arr[:,2]}
if reference_E>0: download_data['estimated_stress_kpa_assumed_calibration']=arr[:,1]*scale
st.download_button("Download tensile curve CSV",pd.DataFrame(download_data).to_csv(index=False),"collagen_curve.csv","text/csv")
st.caption(f"Gradient finite-difference error: {validate_gradient():.2e} · Equilibrium converged at {100*stats['converged_fraction']:.0f}% of strain steps · Small illustrative network")


st.subheader("Multiscale science stack")
st.caption("Stage-status snapshot written by extensions/multiscale_check.py. A prepared stage is not an executed or validated run.")
status_path=Path('outputs/multiscale_status.json')
if status_path.exists():
    snapshot=json.loads(status_path.read_text())
    status_data=[{'Tool':name.replace('_',' ').title(),'Execution status':value['status']}
                 for name,value in snapshot.items() if isinstance(value,dict) and 'status' in value]
    st.dataframe(pd.DataFrame(status_data),hide_index=True,use_container_width=True)
else:
    st.info('Run `python extensions/multiscale_check.py --out outputs` to generate a capability snapshot.')

mmff_path=Path('outputs/atomistic/mmff_bond_scans.csv')
if mmff_path.exists():
    st.markdown('#### Molecular fragment bond-stretch pilot')
    st.caption('Real RDKit MMFF fixed-geometry energy scans, **not** MACE predictions or collagen crosslink-breaking energies.')
    mol_df=pd.read_csv(mmff_path)
    fig_mol=go.Figure()
    for name,group in mol_df.groupby('molecule'):
        fig_mol.add_trace(go.Scatter(x=100*group['relative_extension'],
                        y=group['MMFF_relative_energy_kcal_mol'],
                        mode='lines+markers',name=name.replace('_',' ')))
    fig_mol.update_layout(xaxis_title='Imposed local bond extension (%)',
                          yaxis_title='Relative MMFF energy (kcal/mol)',height=330)
    st.plotly_chart(fig_mol,use_container_width=True)
    st.caption('Each curve is referenced to its own molecule, with the full molecular geometry held rigid apart from the bond-side translation. No solvent, helix, kinetic process or tissue strength is modeled.')


# Added molecular evidence: display only, never a mechanical calibration.
from explorer_evidence_panel import render_molecular_evidence
render_molecular_evidence(st, Path(__file__).resolve().parent)
