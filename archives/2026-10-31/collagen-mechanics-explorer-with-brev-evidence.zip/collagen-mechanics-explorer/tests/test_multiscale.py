"""Verification of truly executed and merely prepared simulation layers."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import numpy as np
import pytest
from simulator import PRESETS,build_network
from extensions.lammps_bridge import energy_gradient, reference_harmonic, write_data,write_input


def test_lammps_harmonic_gradients():
    net=build_network(PRESETS['Young reference'],seed=7,n_cols=6,n_rows=4)
    pos=net.reference.copy();pos[:,0]*=1.06
    energy,grad=energy_gradient(pos,net)
    h=1e-6; i=8
    pos[i,0]+=h; p,_=energy_gradient(pos,net)
    pos[i,0]-=2*h; m,_=energy_gradient(pos,net)
    assert abs((p-m)/(2*h)-grad[i,0])<1e-5


def test_applied_force_is_energy_derivative():
    net=build_network(PRESETS['AGE-rich'],seed=3,n_cols=7,n_rows=4)
    h=1e-4; eps=.08
    _,load,_,_=reference_harmonic(net,eps)
    _,_,ep,_=reference_harmonic(net,eps+h)
    _,_,em,_=reference_harmonic(net,eps-h)
    dU=(ep-em)/(2*h)
    assert dU==pytest.approx(load,rel=5e-3,abs=1e-4)


def test_lammps_coeff_factor_and_grips(tmp_path):
    net=build_network(PRESETS['Young reference'],seed=8,n_cols=6,n_rows=4)
    data=tmp_path/'network.data';inp=tmp_path/'in.collagen'
    write_data(net,.1,data);write_input(net,inp)
    payload=data.read_text();commands=inp.read_text()
    assert f'{len(net.reference)} atoms' in payload
    assert f'{len(net.ends)} bonds' in payload
    assert 'dimension 2' in commands
    assert 'bond_style harmonic' in commands
    assert f'bond_coeff 1 {0.5*net.spring_k[0]:.12g} {net.rest[0]:.12g}' in commands
    assert 'fix lock_left left_grip setforce' in commands


def test_MMFF_chemical_proxy_energy_changes():
    pytest.importorskip('rdkit')
    from extensions.atomistic_pilot import MOLECULES,make_molecule,stretch
    from rdkit.Chem import AllChem
    for cfg in MOLECULES.values():
        mol=make_molecule(cfg['smiles'])
        a,b=cfg['bond'];p=AllChem.MMFFGetMoleculeProperties(mol)
        f0=AllChem.MMFFGetMoleculeForceField(mol,p).CalcEnergy()
        stretched,_,_=stretch(mol,a,b,.14)
        f1=AllChem.MMFFGetMoleculeForceField(stretched,p).CalcEnergy()
        assert f1>f0
