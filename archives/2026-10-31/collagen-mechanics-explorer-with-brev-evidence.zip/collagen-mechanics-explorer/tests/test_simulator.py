import pathlib
import sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))

import numpy as np
import pytest
from simulator import AgingState,PRESETS,build_network,simulate,validate_gradient


def test_gradient_agrees_with_finite_difference():
    assert validate_gradient()<1e-6


def test_reproducibility():
    _,a,m,_=simulate(PRESETS['Young reference'],seed=17,n_cols=6,n_rows=4,strains=np.linspace(0,.14,8))
    _,b,n,_=simulate(PRESETS['Young reference'],seed=17,n_cols=6,n_rows=4,strains=np.linspace(0,.14,8))
    np.testing.assert_allclose(a,b,rtol=0,atol=0)
    assert m==n


def test_geometry_is_paired_across_conditions():
    a=build_network(PRESETS['Young reference'],seed=10)
    b=build_network(PRESETS['AGE-rich'],seed=10)
    np.testing.assert_array_equal(a.reference,b.reference)
    assert (b.kinds=='AGE').sum()>(a.kinds=='AGE').sum()


def test_loading_and_energy():
    _,curve,metric,_=simulate(PRESETS['Fibrotic'],seed=10,n_cols=7,n_rows=5,strains=np.linspace(0,.18,10))
    assert np.isfinite(curve).all()
    assert curve[0,1]==pytest.approx(0,abs=1e-6)
    assert (curve[:,1]>=0).all()
    assert metric['early_stiffness']>0
    assert 0<=metric['peak_strain']<=.18
    assert metric['converged_fraction']>=.9


def test_invalid_input_is_rejected():
    with pytest.raises(ValueError):AgingState(age=1.2)
    with pytest.raises(ValueError):simulate(AgingState(),strains=[.10,.04])
